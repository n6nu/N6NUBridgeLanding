CW receive test file for WS (DeepCW / GT), N6NU 2026-11-15
===========================================================

261107_234830.wav  3:00  ARRL CW Sweepstakes, 20 m, 2026-11-07 23:48:30-23:51:30 UTC.
                         Cut from a FlexRadio I/Q recording at N6NU, USB dial
                         14.04025 MHz, WS format (12 kHz, mono, 16 bit).

No radio needed: WS in CW mode, File > Open, pick the file.

What is on it (audio frequency = RF - 14.04025 MHz)
---------------------------------------------------
Around 1500 Hz (the default Rx frequency): N6RO running at 14.0417 MHz.
N6RO's log for these minutes (his serial, the caller, the caller's exchange):
  0273 23:48  W6KC     117 U 59 LAX
  0274 23:49  NO5Z     155 B 57 NM
  0275 23:49  N2EY      85 A 67 EPA
  0276 23:49  KC4WQ     16 A 79 KY
  0277 23:50  WA3AER   134 U 63 MDC
  0278 23:50  VE5UO    116 U 87 SK
  0279 23:51  K5HDU     35 U 61 UT
N6RO sends e.g. "NO5Z 274 M N6RO 53 EB" and "TU N6RO SS".
The callers sit a little off N6RO's frequency (about 1400-1600 Hz).

Elsewhere in the clip:
  ~1050 Hz  WJ9B running: "N3OC 256 A WJ9B 66 ID", K8FC, VA7DZ ...
  ~250 Hz   VE2FK running: "... U VE2FK 59 QC"
  ~525 Hz   K3TC calling CQ, works VE5UO
  ~1850 / 2550 Hz  "CQ SS KS9W"
  ~2225 Hz  "CQ SS N4ZZ", works K2IY
  ~2825 Hz  "CQ SS K2NV"

What a good decode looks like
-----------------------------
With DeepCW and Rx 1500 Hz, the right-hand window should show N6RO's exchanges
almost letter-perfect ("N2EY 275 M N6RO 53 EB", "KC4WQ 276 M N6RO 53 EB" ...),
with some broken letters where two stations overlap. Our Windows build reads it
that way (about 15 s for the 3 minutes). GT on the same file is weaker on a
crowded band like this. To read another station, set Rx to its frequency and
open the file again.
