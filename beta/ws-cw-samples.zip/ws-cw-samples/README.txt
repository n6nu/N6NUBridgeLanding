CW receive test files for WS (DeepCW / GT), N6NU 2026-11-15
=============================================================

Two real on-air CW recordings in WS's own format (12 kHz, mono, 16 bit).
No radio needed: WS in CW mode, File > Open, pick a file.

261107_231000.wav  3:00  CW Sweepstakes, 20 m, 2026-11-07 23:10 UTC.
                         Cut from a FlexRadio I/Q recording at N6NU: a busy
                         contest band, many stations at once.
261111_230109.wav  1:49  A CW period WS saved itself (Save all), 2026-11-11.

What to look at: the Decoder box (DeepCW should be selectable, not greyed
out, when ONNX Runtime 1.23 or newer is found) and the decoded text in both
windows. Selecting GT and opening the file again gives the comparison.
